library(dplyr)
library(ggplot2)
sim <- function() {
  x <- rnorm(100, 0, 0)
  y <- rnorm(100, 0, .5)
  test <-  t.test(x, y)
  out <- list(t= test$statistic, p = test$p.value, meanx = test$estimate[1],
              meany = test$estimate[2], sig = test$p.value<0.05)
  out
}

df <- data.frame(index = 1:100) %>% 
  mutate(sim = list(sim())) %>% 
  tidyr::unnest(sim)
  
sim()

out <- data.frame()

for(i in 1:50){
  c <- c(rep(1, 100), rep(2, 100))
  x <- c(rnorm(100, mean=0), rnorm(100, mean=-0.5))
  t <- t.test(x~c)
  
  out[i,1] <- t$statistic
  out[i,2] <- t$parameter
  out[i,3] <- t$p.value 
  out[i,4] <- t$estimate[1] - t$estimate[2]
  out[i,5] <- t$conf.int[1]
  out[i,6] <- t$conf.int[2]
}

names(out) <- c("t", "df", "pval", "mean_diff", "ci_low", "ci_high")

out %>% mutate(index = 1:nrow(out)) %>% 
  ggplot(aes(y = mean_diff, x = index, colour = pval<0.05)) +
  geom_point() + 
  geom_errorbar(aes(ymin = ci_low, ymax = ci_high)) + 
  theme_bw() + 
  coord_flip() + 
  geom_hline(aes(yintercept= 0.5), linetype = "dashed") + 
  geom_hline(aes(yintercept= 0), linetype = "dotted", colour = "red") + 
  labs(title = "Simulation of studies", 
       subtitle = "50 t-tests, where population mean difference = 0.5, n = 100",
       x = "Study index",
       y = "Observed Mean Difference")

summarise(out, mean = mean(mean_diff), sd = sd(mean_diff))

biased <- out %>% filter(pval<.05)

biased %>% mutate(index = 1:nrow(biased)) %>% 
  ggplot(aes(y = mean_diff, x = index)) +
  geom_point(colour = "#00BFC4") + 
  geom_errorbar(aes(ymin = ci_low, ymax = ci_high), colour = "#00BFC4") + 
  theme_bw() + 
  coord_flip() + 
  geom_hline(aes(yintercept= 0.5), linetype = "dashed") + 
  geom_hline(aes(yintercept= 0), linetype = "dotted", colour = "red") + 
  labs(title = "Simulation of studies", 
       subtitle = "47 t-tests, where population mean difference = 0.5, n = 100",
       x = "Study index",
       y = "Observed Mean Difference")

summarise(biased, mean = mean(mean_diff), sd = sd(mean_diff))
